$(function(){
 	$('.book_now a').click(function(){
		$('.header_bookingform').slideToggle(200);
	});
});